import UIKit
//
//let operation = BlockOperation {
//    for i in 0...5 {
//        print(i)
//    }
//}
//
//let queue = OperationQueue()
//queue.addOperation(operation)
//
//struct Example {
//    func doTask() {
//        let blockOperation = BlockOperation()
//
//        blockOperation.addExecutionBlock {
//            print("Hello")
//        }
//
//        blockOperation.addExecutionBlock {
//            print("my name is")
//        }
//        blockOperation.addExecutionBlock {
//            print("Slim Shady")
//        }
//
//        let operationQ = OperationQueue()
//        operationQ.addOperation(blockOperation)
//
//        let anotherBlockOp = BlockOperation()
//        anotherBlockOp.addExecutionBlock {
//            print("another one")
//        }
//        operationQ.addOperation(anotherBlockOp)
//        }
//
//    }
//
//let objTest = Example()
//objTest.doTask()


// Dependency

//struct Employee {
//    func syncEmployeeRecords() {
//        print("Syncing records for employees----")
//        Thread.sleep(forTimeInterval: 2)
//        print("Employee sync complete")
//    }
//}
//
//struct Department {
//    func syncOffline() {
//        print("Syncing records for department----")
//        Thread.sleep(forTimeInterval: 2)
//        print("Department sync complete")
//    }
//}
//
//struct SyncManager {
//
//    func syncOfflineRecords() {
//        let employeeSyncOp = BlockOperation()
//        employeeSyncOp.addExecutionBlock {
//            let employee = Employee()
//            employee.syncEmployeeRecords()
//        }
//        let departmentSyncOp = BlockOperation()
//
//        departmentSyncOp.addExecutionBlock {
//            let department = Department()
//            department.syncOffline()
//        }
//
//        //department has dependency on employee
//        departmentSyncOp.addDependency(employeeSyncOp)
//
//        let operationQue = OperationQueue()
//        operationQue.addOperation(employeeSyncOp)
//        operationQue.addOperation(departmentSyncOp)
//    }
//}
//
//let syncObj = SyncManager()
//syncObj.syncOfflineRecords()


// Task 1:
struct Op1 {
    func operation1() {
        print("starting Op 1----")
        Thread.sleep(forTimeInterval: 3)
        print("Op 1 done")
    }
}

struct Op2 {
    func operation2() {
        print("starting Op 2----")
        Thread.sleep(forTimeInterval: 3)
        print("Op 2 done")
    }
}

struct Op3 {
    func operation3() {
        print("starting Op 3----")
        Thread.sleep(forTimeInterval: 3)
        print("Op 3 done")
    }
}

struct SyncManager {
    func opSync() {
        let operSync1 = BlockOperation()
        operSync1.addExecutionBlock {
            let op1 = Op1()
            op1.operation1()
        }
        let operSync2 = BlockOperation()
        operSync2.addExecutionBlock {
            let op2 = Op2()
            op2.operation2()
        }
        let operSync3 = BlockOperation()
        operSync3.addExecutionBlock {
            let op3 = Op3()
            op3.operation3()
        }
        
        operSync2.addDependency(operSync1)
        operSync3.addDependency(operSync2)
        
        let operationQue = OperationQueue()
        operationQue.addOperation(operSync1)
        operationQue.addOperation(operSync2)
        operationQue.addOperation(operSync3)
    }
}

let syncOb = SyncManager()
syncOb.opSync()


// Task 2:
DispatchQueue.global().async {
    print("task 1")
}
DispatchQueue.global().async {
    print("task 2")
}
